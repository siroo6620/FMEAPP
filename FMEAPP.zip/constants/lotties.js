const lottieList = {
  successTick: require("../assets/lottie/success-tick.json")
}


export default lottieList