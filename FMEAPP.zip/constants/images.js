const imagesList = [
  require("../assets/logo1.png"), //0
  require("../assets/fmeapp.png"),
  require("../assets/rice.png"),
  require("../assets/Farmer.png"),
  require("../assets/Mechanic.png"),
  require("../assets/Officeworker.png"),
  require("../assets/app/FME-Img1.png"),
];

export default imagesList;
