export const userRoles = {
  farmer: "farmer",
  serviceProvider: "serviceProvider",
  agent: "agent",
  admin: "admin"
}